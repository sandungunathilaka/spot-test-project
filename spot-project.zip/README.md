Project Name - order
Database name - order.sql
php script name - updatestatus.php
